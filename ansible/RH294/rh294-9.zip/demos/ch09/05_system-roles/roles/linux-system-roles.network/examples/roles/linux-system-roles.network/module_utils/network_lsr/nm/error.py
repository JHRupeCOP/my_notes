# SPDX-License-Identifier: BSD-3-Clause

from __future__ import absolute_import, division, print_function

__metaclass__ = type


class LsrNetworkNmError(Exception):
    pass
